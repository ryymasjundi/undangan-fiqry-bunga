Upload the contents of this folder to a GitHub repository and enable GitHub Pages (branch: main, folder: /) to publish the site at https://undangan-fiqry-bunga.github.io/

RSVP currently stores data to browser localStorage. To connect to Google Spreadsheet, replace the RSVP handler with a POST to your Apps Script or webhook endpoint.